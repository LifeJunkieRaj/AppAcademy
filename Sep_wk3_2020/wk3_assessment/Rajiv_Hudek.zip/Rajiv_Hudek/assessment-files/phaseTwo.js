let addTwo = function(num) {

    return num = num + 2;
}
console.log(addTwo(5))
