/***********************************************************************
Write a function `mostFrequentLetter(string)` that will takes a
string as an argument and returns the character that appears the
most often. In case of a tie, you may return any of the characters.
The string will have at least one character.

Examples:

mostFrequentLetter("apple") // "p"
mostFrequentLetter("banana") // "a"
mostFrequentLetter("What about a longer string?") // " "
***********************************************************************/

function mostFrequentLetter(string) {
	let count = 0
	let letters = string.split("");
    letters.forEach(el => {
        if (newObj[el] === undefined) {
            newObj[el] = 1;
    //We iterate through the array and if that letter is being seen for the first time (or is undefined) then we ask it be put in our empty object named newObj in the format of a key-value pair where the key is the new letter and the value is at this point set to signify that this is the first time the code has seen this letter.
        } else {
			newObj[el]++;
		} else if ()

}

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
module.exports = mostFrequentLetter;
