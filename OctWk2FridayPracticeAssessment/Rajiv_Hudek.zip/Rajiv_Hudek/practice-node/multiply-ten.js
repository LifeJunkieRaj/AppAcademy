let multiplyTen = (num) => {
    return num * 10;
}

console.log(multiplyTen(5))
